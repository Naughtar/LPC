import re
import time
import os
from shutil import copyfileobj
from urllib.request import urlopen
import requests
from bs4 import BeautifulSoup as bs
from openpyxl import Workbook, load_workbook
import json
from datetime import datetime


class Webs():
    def __init__(self,c,URL):
        self.url=URL
        self.patrones=[r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)", r"kawasaki",r"[\d]{1,2}/[\d]{1,2}/[\d]{4}",r"(\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4}|\d{3}[-\.\s]??\d{4})"]
        self.desc=re.compile(r"((http|https)\:\/\/)?[a-zA-Z0-9\.\/\?\:@\-_=#]+\.([a-zA-Z]){2,6}([a-zA-Z0-9\.\&\/\?\:@\-_=#])*")
        self.check = False
        self.c=c


    def descargar(self):
        pagina=requests.get(self.url)
        if pagina.status_code == 200:
            tipo=0
            menciones=""
            soup = bs(pagina.content, "html.parser")            
            print("Espere un momento", end="")
            for i in range(0,3):
                time.sleep(1)
                print(".",end="")
            
            for patron in self.patrones:
                control = ""
                while True:
                    if tipo==0:
                        menciones+="\n Correos Encontrados: \n"
                        break
                    if tipo==1:
                        menciones+="\n Menciones del equipo encontradas: \n"
                        break
                    if tipo==2:
                        menciones+="\n Fechas encontradas: \n"
                        break
                    if tipo==3:
                        menciones+="\n Numeros encontrados: \n"
                        break
                busqueda=re.compile(patron)
                parrafos = soup.findAll(text=busqueda)                
                for elemento in parrafos:
                    if not re.search(self.desc, elemento):
                        control += elemento+"\n"
                        self.check=True
                if control == "":
                    control=self.rellenar(tipo)
                else:
                    menciones += control
                tipo+=1
                print("-------------  -------------  -------------  -------------  ")
            try:
                menciones+="\n\n Cabeceras encontradas: \n\n"
                for a in ["h1","h2","h3","h4","h6"]:
                    cabeceras=soup.find_all(a)
                    for cabecera in cabeceras:
                        buscar=re.compile(self.patrones[1])
                        if re.search(buscar,str(cabecera)):
                            menciones+=(str(cabecera)+"\n")
            except Exception as e:
                print (e)
                
                
                    
            print("Guardando datos...")
            time.sleep(3)
            menciones+="-----------------------Siguiente Pagina-----------------------"
            self.guardar(menciones)
            print("Datos guardados")
                
            if self.check:
                self.imagenes(pagina)
        else:
            print("Error ",pagina.status_code)

       
    def imagenes(self,pagina):
        soup = bs(pagina.content,'html.parser')
        counter = 1
        imgs = soup.findAll('img')
        try:
            for img in imgs:
                if img.get('src')[:1]!="/" and counter<4:
                    with urlopen(img.get('src')) as in_stream, open('imagenes\\Pag%simagen%s.jpg'%(str(self.c),str(counter)), 'wb') as out_file:
                        copyfileobj(in_stream, out_file)
                        print("Se ha guardado Pag%dimagen%d.jpg exitosamente"%(self.c,counter))
                        counter+=1
        except:
            print("No se pudo tener accceso a las imagenes")
        
    def rellenar(self, op):
        while True:
            if op==0:
                relleno=str(input("\nNo se encontraron correos, desea ingresar alguno?\n"))
                break
            elif op==1:
                relleno=str(input("No se encontraron menciones, desea ingresar una?\n "))
            elif op==2:
                relleno=str(input("No se encontraron fechas, desea ingresar alguna?\n"))
            elif op==3:
                relleno=str(input("No se encontraron numeros de telefono, desea ingresar uno?\n"))
            return relleno


    def guardar(self,menciones):
        archivo=os.path.join(os.getcwd(),'Datos\\Logs.txt')
        datos = open(archivo,"a", encoding='utf-8', errors='ignore')
        datos.write(menciones)
        datos.close()


def main():
    pagina = input("Inserte el sitio web a tomar:\n")
    try:
        os.makedirs(".\Imagenes")
        os.makedirs(".\Datos")
    except:
        pass
    try:
        info = Webs(1,pagina)
        info.descargar()
    except Exception as e:
        print(e)


if __name__ == '__main__':
    main()
