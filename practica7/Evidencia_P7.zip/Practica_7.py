import nmap
import socket
import os

def guardado(datos):
    try:
        os.makedirs(".\p7")
    except:
        pass
    es = open('p7\\ipdata.txt','a',encoding='utf-8', errors='ignore')
    es.write(datos)
    es.close()


def ip_sc(ip):
    nm = nmap.PortScanner()
    nm.scan(ip, '22-443')
    datos = ''
    for host in nm.all_hosts():
        datos += ('----------------------------------------------------')
        datos += ('\nHost : %s (%s)' % (host, nm[host].hostname()))
        datos += ('\nEstado : %s' % nm[host].state())
        for protocolo in nm[host].all_protocols():
            datos += ('\n----------')
            datos +=('\nprotocolo : %s' % protocolo)
            lport = sorted(nm[host][protocolo].keys())
            for puerto in lport:
                datos += ('\nPuerto: %s\tEstado: %s' % (puerto, nm[host][protocolo][puerto]['state']))
    print(datos)
    guardado(datos)

def main():
    # Aqui es donde se va a tomar la ip del usuario
    # para hacer un scn de los puertos
    input('Se tomara la ip local, presione enter para continuar\n')
    hostname = socket.gethostname()
    lip = socket.gethostbyname(hostname)
    print(lip)
    while True:
        
        print('Que desea hacer?')
        op = int(input('-1.- Scan IP local\n-2.- IP publica\n-Etc.-Salir\n'))
        if op == 1:
            ip_sc(lip)
            print('Proceso terminado con exito')
        elif op == 2:
            print('Por razones de seguridad, no se saca ip publica\n')
            pip = str(input('Inserte su IP publica:\n'))
            ip_sc(pip)
            print('\n\nProceso terminado con exito')
        else:
            print('Saliendo del programa')
            break


if __name__ == '__main__':
    main()
